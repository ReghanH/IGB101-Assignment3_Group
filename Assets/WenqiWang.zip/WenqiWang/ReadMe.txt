Assets and Resources used

Fantastic Skybox FREE by Render King
Source: Unity Assets Store - https://assetstore.unity.com/packages/2d/textures-materials/sky/fantasy-skybox-free-18353#description
License: Standard Unity Asset Store EULA

Marble Design Materials by Aquast
Source: Unity Assets Store - https://assetstore.unity.com/packages/2d/textures-materials/tiles/marble-design-materials-284996
License: Standard Unity Asset Store EULA

Picture frames with photos by 3Dfrk
Source: Unity Assets Store - https://assetstore.unity.com/packages/3d/props/interior/picture-frames-with-photos-106907#asset_quality
License: Standard Unity Asset Store EULA

Wood Pattern Material by FrOzBi
Source: Unity Assets Store - https://assetstore.unity.com/packages/2d/textures-materials/wood/wood-pattern-material-170794
License: Standard Unity Asset Store EULA